const numbers = [1, 7, 10, 9, 8];

const max = Math.max(...numbers);

console.log("le nombre maximum est:", max); // le nombre maximum est: 10
